﻿(function () {
    // Union of Chrome, Firefox, IE, Opera, and Safari console methods
    var methods = ["assert", "cd", "clear", "count", "countReset",
        "debug", "dir", "dirxml", "error", "exception", "group", "groupCollapsed",
        "groupEnd", "info", "log", "markTimeline", "profile", "profileEnd",
        "select", "table", "time", "timeEnd", "timeStamp", "timeline",
        "timelineEnd", "trace", "warn"];
    var length = methods.length;
    var console = (window.console = window.console || {});
    var method;
    var noop = function () { };
    while (length--) {
        method = methods[length];
        // define undefined methods as noops to prevent errors
        if (!console[method])
            console[method] = noop;
    }
})();

var access_token, id_token;
var currentURL = window.location.href;
var encoded_client_id = "";

function show(data) {
    if (typeof data !== 'string') {
        document.querySelector(".results").textContent += JSON.stringify(data, null, 2);
    }
    else {
        document.querySelector(".results").textContent += data;
    }
    document.querySelector(".results").textContent += '\r\n';
}

function clear() {
    document.querySelector(".results").textContent = "";
}

function rand() {
    return (Date.now() + "" + Math.random()).replace(".", "");
}

var currentURL = window.location.href;
if (currentURL.indexOf(':63855') > 0) {
    var client_id = 'dev_diagnostic';
} else {
    var client_id = 'mpog_diagnostic';
}

function getToken() {
    var authorizationUrl = 'https://www.aspirecqi.org/HIEBus/identityserver/connect/authorize';
    var response_type = "id_token";
    var scope = "openid profile roles email";

    var state = rand();
    var nonce = rand();
    localStorage[client_id + "_state"] = state;
    localStorage[client_id + "_nonce"] = nonce;

    var url =
        authorizationUrl + "?" +
        "client_id=" + encodeURI(client_id) + "&" +
        "redirect_uri=" + encodeURI(currentURL) + "&" +
        "response_type=" + encodeURI(response_type) + "&" +
        "scope=" + encodeURI(scope) + "&" +
        "state=" + encodeURI(state) + "&" +
        "nonce=" + encodeURI(nonce);
    window.location = url;
}

function validateToken() {
    var hash = window.location.hash.substr(1);
    if (hash === "") {
        getToken();
        return;
    }

    var result = hash.split('&').reduce(function (result, item) {
        var parts = item.split('=');
        result[parts[0]] = parts[1];
        return result;
    }, {});
    if (result.error) {
        show(result);
        return;
    }
    if (result.state !== localStorage[client_id + "_state"]) {
        show("invalid state");
        return;
    }
    localStorage.removeItem(client_id + "_state");
    id_token = result.id_token;
    if (!id_token) {
        show("no id_token");
        return;
    }
    var cert = 'MIIC4zCCAcugAwIBAgIBZzANBgkqhkiG9w0BAQUFADAYMRYwFAYDVQQDEw1DYXJlRXZvbHV0aW9uMB4XDTE1MDYxNzE4NDQxM1oXDTE4MDYxNjE4NDQxM1owFDESMBAGA1UEAxMJQXNwaXJlU1RTMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtSH64dJnqmHwF1fEGxH8V9f6MlXszHoZg4qEY4f6jqRVo0eumHEyxfPIFCwoHKcYpHjV9ti1rjEx/n27nfVOdYymjY6ewTpovOkiTw7VpRI7SOEP4HNlo4OFsHcefRfWv/YQrWQqIfvVaeBr6IOGrJ56u4XpsrL382callPclGcHyheESdbhjgpp3XoXiAYr+YHEemGXOqYT7BqnFRNlZLpHcj/65qtB5E8u0GWnrlTLkuSvFp0+Ppu1dAIAocFKkyfy3ekTcjuC6RN/jG3NJBC5p1ZiOicKOjBIL7SFT01QeMR/rQHk0mfpktzOHjlc8CeTzXQUwUcMJgXOUe/shwIDAQABozwwOjAJBgNVHRMEAjAAMA4GA1UdDwEB/wQEAwIE8DAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwDQYJKoZIhvcNAQEFBQADggEBAKExcLC3dxo43K+fHrq6IbpOf1lUK5b68bUy599dCK8IzfxyHC/xnLI+UsyWAA7a3KdoUc5Q1uX8knI7LO5RM63RKKxHp+QKNAUn7jBOLR5ZLCvWmFS5QFdJZPd1geu51CZCwxm0VT+a39Sq+m01yvhrDtbU8YbsmsdifCYwaJi3iuNOEMkJmUDJ7jxvC6BbYGHUXuED2SY5zyAURugkGjxMxfWueVymlydGKKSbfZWT43ivnMMdKvOXzrKNjlLKU+DAMqyzed6wtwi2qToq3vlkx0lAf3SMDNHAhD+p2PmneigJXtRfKkSjMwwEizCGusAMOMhpWk+j07K2b+q3Yag=';
    var jws = new KJUR.jws.JWS();
    if (jws.verifyJWSByPemX509Cert(id_token, cert)) {
        var id_token_contents = JSON.parse(jws.parsedJWS.payloadS);
        if (localStorage[client_id + "_nonce"] !== id_token_contents.nonce) {
            show("Invalid nonce");
            return;
        }
        localStorage.removeItem("_nonce");
        if (id_token_contents.iss !== "https://www.aspirecqi.org/HIEBus/identityserver") {
            show("Invalid issuer");
            return;
        }
        if (id_token_contents.aud !== client_id) {
            show("Invalid audience");
            return;
        }
        var now = parseInt(Date.now() / 1000);
        var diff = now - id_token_contents.iat;
        if (diff > (5 * 60)) {
            show("Token issued too long ago");
            return;
        }
        if (id_token_contents.exp < now) {
            show("Token expired");
            return;
        }
        var role = true;
        //var role = false;
        //if (typeof id_token_contents["role"] === 'undefined' || id_token_contents["role"] === null) {
        //    role = false;
        //    is_user = false;
        //}
        if (role === false) {
            alert("You don't have permission to view internal version. Please use other mpog account or you are not allowed to access this website.");
            window.location.href = "Default.aspx";
        }
        else {
            var dataToSend = {
                token: result.id_token
            };
            $.when(
                $.ajax({
                    type: 'POST',
                    url: 'Default.aspx/setSession',
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(dataToSend),
                    dataType: 'json'
                }))
                .done(function (data) {
                    window.location.href = "Graph.aspx";
                })
                .fail(function () {
                    alert("Server error. Log in failed. Please try again.");
                });
        }
    }
}

//function delete_cookie(name, path, domain) {
//    document.cookie = name + "=" +
//        ((path) ? ";path=" + path : "") +
//        ((domain) ? ";domain=" + domain : "") +
//        ";expires=Thu, 01 Jan 1970 00:00:01 GMT";
//}


$(document).ready(function () {
    if (window.location.href.indexOf("/?s=") === -1) {
        validateToken();
    }
});