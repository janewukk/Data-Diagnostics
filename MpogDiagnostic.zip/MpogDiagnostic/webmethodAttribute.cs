﻿using System;

namespace MpogDiagnostic
{
    internal class webmethodAttribute : Attribute
    {
    }
}